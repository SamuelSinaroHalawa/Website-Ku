<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Universitas MBP</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #40E0D0;
        }

        .header .logo {
            width: 80px;
            height: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .header .logo img {
            max-width: 100%;
            max-height: 100%;
        }

        .header .title {
            flex-grow: 1;
            text-align: center;
            color: white;
            font-size: 35px;
            font-weight: bold;
        }

        .main {
            display: flex;
            flex-grow: 1;
        }

        .sidebar {
            width: 20%;
            background-color: #f4f4f4;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        /* Tombol Menu */
        .sidebar ul li {
            margin: 10px 0;
            text-align: center;
        }

        .sidebar ul li a {
            text-decoration: none;
            display: inline-block;
            padding: 15px 30px;
            color: white;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 25px;
            background: linear-gradient(45deg, #40E0D0, #3bafaf);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        /* Efek Hover */
        .sidebar ul li a:hover {
            background: linear-gradient(45deg, #3bafaf, #40E0D0);
            transform: translateX(10px) scale(1.05);
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.3);
        }

        /* Animasi Tombol */
        .sidebar ul li a:active {
            transform: scale(0.98);
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        /* Tampilan Konten */
        .content {
            flex-grow: 1;
            padding: 20px;
            text-align: center;
        }

        .footer {
            text-align: center;
            padding: 10px;
            background-color: #40E0D0;
        }

        /* Formulir Kontak */
        .contact-form {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .contact-form label {
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            width: 100%;
        }

        .contact-form input,
        .contact-form textarea,
        .contact-form select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 14px;
        }

        .contact-form input[type="submit"],
        .contact-form button {
            background-color: #40E0D0;
            color: white;
            font-size: 16px;
            border: none;
            padding: 12px 20px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            border-radius: 5px;
            width: 100%;
        }

        .contact-form input[type="submit"]:hover,
        .contact-form button:hover {
            background-color: #3bafaf;
            transform: scale(1.05);
        }

        .contact-form input[type="submit"]:active,
        .contact-form button:active {
            background-color: #369d99;
            transform: scale(0.98);
        }

        /* Pesan Sukses */
        .success-message {
            color: #28a745;
            font-size: 16px;
            margin-top: 20px;
            font-weight: bold;
            display: none;
            text-align: center;
        }

         /* Tampilan Gallery */
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;  /* Menyusun gambar di tengah */
            gap: 40px;  /* Jarak antar gambar lebih lebar */
            margin-top: 40px;
        }

        .gallery-item {
            width: 450px;  /* Ukuran gambar lebih besar */
            text-align: center;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);  /* Bayangan lebih besar untuk efek 3D */
            border-radius: 15px;
            overflow: hidden;
            background-color: #fff;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .gallery-item img {
            width: 100%;
            height: auto;
            display: block;
            border-bottom: 4px solid #40E0D0;
            transition: transform 0.3s ease;
        }

        .gallery-item p {
            padding: 10px;
            font-size: 18px;  /* Ukuran teks sedikit lebih besar */
            color: #333;
        }

        .gallery-item:hover {
            transform: translateY(-10px);
            box-shadow: 0px 8px 25px rgba(0, 0, 0, 0.3);  /* Efek hover dengan bayangan lebih besar */
        }
</style>
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <img src="assets/images/logo.png" alt="Logo">
            </div>
            <div class="title">UNIVERSITAS MANDIRI BINA PRESTASI</div>
        </div>

        <div class="main">
            <div class="sidebar">
                <ul>
                    <li><a href="#" onclick="goToHome()">Home</a></li>
                    <li><a href="#" onclick="goToProfile()">Profile</a></li>
                    <li><a href="#" onclick="goToGallery()">Gallery</a></li>
                    <li><a href="#" onclick="goToContact()">Contact Us</a></li>
                </ul>
            </div>

            <div class="content" id="content">
                <h1>Contact Us</h1>
                <form class="contact-form" onsubmit="handleSubmit(event)">
                    <label for="nama">Nama:</label>
                    <input type="text" id="nama" name="nama" placeholder="Masukan Nama Anda" required>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Masukan Email Anda" required>

                    <label for="jenis_kelamin">Jenis Kelamin:</label>
                    <select id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="">Pilih Jenis Kelamin</option>
                        <option value="male">Pria</option>
                        <option value="female">Wanita</option>
                    </select>

                    <label for="alamat">Alamat:</label>
                    <input type="text" id="alamat" name="alamat" placeholder="Masukan Alamat Anda">

                    <label for="pesan">Pesan:</label>
                    <textarea id="pesan" name="pesan" rows="4" placeholder="Masukan Pesan Anda"></textarea>

                    <input type="submit" value="Kirim">
                    <button type="reset">Batal</button>
                </form>
                <div class="success-message" id="successMessage">
                    <strong>Terima Kasih!</strong> Pesan Anda telah terkirim dengan sukses.
                </div>
            </div>
        </div>

        <div class="footer">
            Copyright : 22100097 - Samuel Sinaro Halawa
        </div>
    </div>

    <script>
        function goToHome() {
            document.getElementById('content').innerHTML = '<h1>Welcome to Home</h1><p>This is the Home page content.</p>';
        }

        function goToProfile() {
        document.getElementById('content').innerHTML = `
        <h1 style="font-size: 32px; font-weight: bold; color: #333; text-align: center; margin-bottom: 30px;">Profile</h1>
        <div class="profile" style="display: flex; align-items: center; justify-content: center; text-align: left; gap: 40px;">
            <!-- Gambar Profil -->
            <div style="width: 250px; height: 250px; box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; border: 6px solid #40E0D0;">
                <img src="assets/images/fp.png" alt="Profile Picture" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
            </div>
            
            <!-- Informasi Profil -->
            <div style="max-width: 500px; box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2); border-radius: 10px; padding: 30px; background-color: #fff;">
                <table style="width: 100%; font-size: 18px; color: #555; border-spacing: 15px;">
                    <tr>
                        <th style="text-align: left; font-size: 20px; font-weight: bold;">Attribut</th>
                        <th style="text-align: left; font-size: 20px; font-weight: bold;">Detail</th>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding-right: 20px;">Nama</td>
                        <td>Samuel Sinaro Halawa</td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding-right: 20px;">NIM</td>
                        <td>22100097</td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding-right: 20px;">Jurusan</td>
                        <td>Sistem Informasi</td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold; padding-right: 20px;">Universitas</td>
                        <td>Universitas Mandiri Bina Prestasi</td>
                    </tr>
                </table>
            </div>
        </div>
         `;
        }

        function goToGallery() {
        document.getElementById('content').innerHTML = `
        <h1 style="font-size: 36px; font-weight: bold; color: #333; text-align: center; margin-bottom: 40px;">Gallery</h1>
        <div class="gallery" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; padding: 0 20px;">
            <!-- Gambar 1 -->
            <div class="gallery-item" style="position: relative; overflow: hidden; border-radius: 15px; box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1); transition: transform 0.3s ease; cursor: pointer;">
                <img src="assets/images/sam1.jpg" alt="Gallery Image 1" style="width: 100%; height: 100%; transition: transform 0.3s ease; border-radius: 15px; object-fit: cover; transform: scale(1);">
                <div class="gallery-description" style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0, 0, 0, 0.6); color: white; padding: 15px; text-align: center; font-size: 20px; font-weight: bold; border-radius: 0 0 15px 15px;">Perjalanan Menuju Gunung Sibayak</div>
            </div>
            <!-- Gambar 2 -->
            <div class="gallery-item" style="position: relative; overflow: hidden; border-radius: 15px; box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1); transition: transform 0.3s ease; cursor: pointer;">
                <img src="assets/images/Segelas Kopi.jpg" alt="Gallery Image 2" style="width: 100%; height: 100%; transition: transform 0.3s ease; border-radius: 15px; object-fit: cover; transform: scale(1);">
                <div class="gallery-description" style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0, 0, 0, 0.6); color: white; padding: 15px; text-align: center; font-size: 20px; font-weight: bold; border-radius: 0 0 15px 15px;">Ilustrasi dari desain dengan Tema Kopi</div>
            </div>
        </div>
        `;
        }

        function goToContact() {
        document.getElementById('content').innerHTML = `
        <h1 style="font-size: 32px; font-weight: bold; color: #333; text-align: center; margin-bottom: 30px;">Contact Us</h1>
        <form class="contact-form" onsubmit="handleSubmit(event)" style="max-width: 700px; margin: 0 auto; background-color: #fff; padding: 30px; border-radius: 10px; box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);">
            <label for="nama" style="font-size: 18px; font-weight: bold;">Nama:</label>
            <input type="text" id="nama" name="nama" placeholder="Masukan Nama Anda" required style="width: 100%; padding: 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px;">

            <label for="email" style="font-size: 18px; font-weight: bold;">Email:</label>
            <input type="email" id="email" name="email" placeholder="Masukan Email Anda" required style="width: 100%; padding: 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px;">

            <label for="jenis_kelamin" style="font-size: 18px; font-weight: bold;">Jenis Kelamin:</label>
            <select id="jenis_kelamin" name="jenis_kelamin" required style="width: 100%; padding: 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px;">
                <option value="">Pilih Jenis Kelamin</option>
                <option value="male">Pria</option>
                <option value="female">Wanita</option>
            </select>

            <label for="alamat" style="font-size: 18px; font-weight: bold;">Alamat:</label>
            <input type="text" id="alamat" name="alamat" placeholder="Masukan Alamat Anda" style="width: 100%; padding: 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px;">

            <label for="pesan" style="font-size: 18px; font-weight: bold;">Pesan:</label>
            <textarea id="pesan" name="pesan" rows="4" placeholder="Masukan Pesan Anda" style="width: 100%; padding: 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px;"></textarea>

            <input type="submit" value="Kirim" style="background-color: #40E0D0; color: white; font-size: 18px; border: none; padding: 15px 20px; cursor: pointer; border-radius: 8px; transition: background-color 0.3s, transform 0.2s; width: 100%;">
            <button type="reset" style="background-color: #f44336; color: white; font-size: 18px; border: none; padding: 15px 20px; cursor: pointer; border-radius: 8px; transition: background-color 0.3s, transform 0.2s; width: 100%; margin-top: 10px;">Batal</button>
        </form>
        
        <div class="success-message" id="successMessage" style="display: none; color: #28a745; font-size: 18px; font-weight: bold; text-align: center; margin-top: 30px;">
            <strong>Terima Kasih!</strong> Pesan Anda telah terkirim dengan sukses.
        </div>
        `;
        }


        function handleSubmit(event) {
            event.preventDefault();
            const successMessage = document.getElementById('successMessage');
            successMessage.style.display = 'block';
        }
    </script>
</body>
</html>
